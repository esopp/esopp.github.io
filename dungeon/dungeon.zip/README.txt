A Pen created at CodePen.io. You can find this one at http://codepen.io/esopp/pen/xOZmGe.

 ReactJS. 
You are lost in a scary dungeon. For some reason. Find the boss in dungeon 4 and fight your way out!